from distutils.core import setup

setup(
    name = 'PythonTestModule',
    version = '1.1.1',
    py_modules = ['PrintData'],
    author = 'greenjoa',
    author_email = 'greenjoa@gmail.com',
    url = 'http://greenjoa.com',
    description = 'Test Module',
    )